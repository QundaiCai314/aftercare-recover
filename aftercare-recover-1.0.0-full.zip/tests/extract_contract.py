"""Reproduce the package's mechanical subset from a supplied central schema."""
import json,re,hashlib,argparse
from pathlib import Path
def extract(source,destination):
    raw=Path(source).read_bytes();central=json.loads(raw.decode('utf-8-sig'))
    queue=['aftercare-recoverRequest','aftercare-recoverResult','TaskSnapshot','FailureEvent','ExecutionReceipt','OperationLedger','PlatformView','OutcomeReport','Action','Observation'];seen=set()
    while queue:
        k=queue.pop()
        if k in seen:continue
        seen.add(k);queue+=re.findall(r'"\$ref": "#/\$defs/([^"]+)"',json.dumps(central['$defs'][k]))
    result={'$schema':central['$schema'],'$defs':{k:central['$defs'][k] for k in sorted(seen)}}
    Path(destination).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return hashlib.sha256(raw).hexdigest()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('destination');a=p.parse_args();print(extract(a.source,a.destination))
