import json,re,sys,hashlib
from pathlib import Path
from jsonschema import Draft202012Validator,FormatChecker
ROOT=Path(__file__).resolve().parents[1];PKG=ROOT/'aftercare-recover'
sys.path.insert(0,str(PKG/'scripts'));from check_plan import structural
def main():
    checks=[]; skipped=[]
    def record(name,ok):checks.append({'name':name,'pass':bool(ok)})
    s=json.loads((ROOT/'candidate/recovery-context.schema.json').read_text(encoding='utf-8'));Draft202012Validator.check_schema(s)
    v=Draft202012Validator(s,format_checker=FormatChecker())
    for p in (ROOT/'candidate').glob('*.json'):
        if p.name.endswith('schema.json'):continue
        errors=list(v.iter_errors(json.loads(p.read_text(encoding='utf-8'))))
        record('candidate:'+p.name,bool(errors) if p.name.startswith('negative') else not errors)
    for p in (ROOT/'examples').glob('*-request.json'):record('request:'+p.name,not structural(json.loads(p.read_text(encoding='utf-8')),'aftercare-recoverRequest'))
    for p in (ROOT/'examples').glob('*-result.json'):record('result:'+p.name,not structural(json.loads(p.read_text(encoding='utf-8')),'aftercare-recoverResult'))
    for p in PKG.rglob('*.md'):
        for ref in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
            if '://' not in ref:record('link:'+str(p.relative_to(PKG))+':'+ref,(p.parent/ref).exists())
    schema=json.loads((PKG/'references/recover.schema.json').read_text(encoding='utf-8'));Draft202012Validator.check_schema(schema)
    audit=json.loads((ROOT/'source-audit.json').read_text(encoding='utf-8'))
    # Checking original sources is optional when running outside the author's machine.
    for a in audit:
        p=Path(a['path'])
        if p.exists():record('source_unchanged:'+p.name,hashlib.sha256(p.read_bytes()).hexdigest()==a['sha256'])
        else:skipped.append({'name':'source_unchanged:'+p.name,'reason':'external source not included in public package'})
    result={'skipped':skipped,'checks':checks,'pass':all(x['pass'] for x in checks),'scope':'Structure, references, examples, candidate schemas and available source hashes only.'}
    (ROOT/'tests/package-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'pass':result['pass'],'checks':len(checks),'failed':[x for x in checks if not x['pass']]},ensure_ascii=False));return not result['pass']
if __name__=='__main__':raise SystemExit(main())
