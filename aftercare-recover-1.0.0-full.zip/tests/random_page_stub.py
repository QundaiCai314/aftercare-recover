"""Synthetic semantic selector. Receives only visible page data, never seeds/truth.
This is NOT the Skill/model and NOT a real platform adapter.
"""
def select(page, target):
    if page['loading']: return {'state':'stop','reason':'loading','control':None}
    overlay=page['overlay']
    if overlay and (overlay['purpose']!='notice' or overlay['data_loss']!='none'):
        return {'state':'handoff','reason':'unsafe_overlay','control':None}
    if overlay: return {'state':'observe','reason':'needs_separate_close_step','control':None}
    candidates=[c for c in page['controls'] if c['item']==target and c['role']=='aftersales' and c['visible']]
    if len(candidates)!=1:return {'state':'stop','reason':'ambiguous_or_missing','control':None}
    return {'state':'located','reason':'semantic_context','control':candidates[0]['id']}
