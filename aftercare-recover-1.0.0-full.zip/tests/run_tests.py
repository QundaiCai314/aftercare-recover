"""Author-authored checker tests; no model/browser/production effects."""
import json,sys,time,copy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'aftercare-recover/scripts'))
from check_plan import check,structural

def main():
    cases=json.loads((ROOT/'tests/cases.json').read_text(encoding='utf-8'))
    rows=[]
    for c in cases:
        before=json.dumps(c,sort_keys=True);start=time.perf_counter()
        got=check(c['request'],c['result'],c['host'])
        expected=c['expected_error']
        ok=any(expected in e for e in got['errors']) if expected else not got['errors']
        rows.append({'id':c['id'],'scenario':c['scenario'],'pass':ok,'errors':got['errors'],
            'elapsed_ms':round((time.perf_counter()-start)*1000,3),'input_unchanged':before==json.dumps(c,sort_keys=True),
            'automatic_execution_allowed':got['automatic_execution_allowed'],'actual_recovery_success':None,
            'external_actions':0,'duplicate_external_actions':0,'human_intervention_actual':None})
    base=cases[0];neg=[]
    for label,change in [
        ('unknown_field',lambda q,r:r['data'].update(approved=True)),
        ('invalid_strategy',lambda q,r:r['data'].update(strategy='retry_submit')),
        ('missing_required',lambda q,r:q['inputs'].pop('ledger')),
        ('completed_with_issue',lambda q,r:r['issues'].append({'code':'tool_failure','message':'x','retryable':False,'evidence_refs':[]})),
        ('wrong_skill',lambda q,r:q.update(skill_id='aftercare-verify')),
        ('ask_user_no_question',lambda q,r:r['data'].update(strategy='ask_user')),
        ('stop_with_steps',lambda q,r:r['data'].update(strategy='stop')),
        ('call_mismatch',lambda q,r:r.update(call_id='different')),
        ('null_data',lambda q,r:r.update(data=None,status='needs_user',questions=[{'question_id':'q','text':'x','choices':[]}]))]:
        q,r=copy.deepcopy(base['request']),copy.deepcopy(base['result']);change(q,r)
        res=check(q,r,base['host']);neg.append({'case':label,'pass':bool(res['errors']),'errors':res['errors']})
    # Repetition is pure and must not reset budget or manufacture events.
    repeated=cases[22];before=copy.deepcopy(repeated['host'])
    rep=[check(repeated['request'],repeated['result'],repeated['host']) for _ in range(10)]
    invariants={'repeated_calls_blocked':all('budget_exhausted' in x['errors'] for x in rep),
       'budget_and_ledger_unchanged':before==repeated['host'],
       'plan_is_not_success':rows[25]['actual_recovery_success'] is None,
       'all_inputs_unchanged':all(x['input_unchanged'] for x in rows),
       'no_execution_permission':all(x['automatic_execution_allowed'] is False for x in rows)}
    # Separate, explicit downstream failure stub for scenario 26: never infer success from plan validity.
    recovery_trace={'fixture_only':True,'plan_validation_passed':not check(base['request'],base['result'],base['host'])['errors'],
                    'downstream_observation':'原入口仍未出现','downstream_effect':'confirmed_failure','recovery_success':False}
    invariants['downstream_failure_not_success']=recovery_trace['plan_validation_passed'] and recovery_trace['recovery_success'] is False
    result={'type':'author_authored_validator_tests','cases':rows,'negative_contract_cases':neg,'invariants':invariants,'scenario_26_failure_stub':recovery_trace,
        'pass':all(x['pass'] for x in rows+neg) and all(invariants.values()),
        'limits':'Checks authored output fixtures against authored host witnesses; not independent model behavior or browser end-to-end.'}
    (ROOT/'tests/results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'pass':result['pass'],'cases':len(rows),'negatives':len(neg),'failed':[x for x in rows+neg if not x['pass']]},ensure_ascii=False))
    return not result['pass']
if __name__=='__main__':raise SystemExit(main())
