"""Evaluator-only synthetic variant generator. Never expose this file to a model run.
Deterministic development and held-out seeds; no seed-specific recovery code.
"""
import json,random,time,hashlib
from pathlib import Path
from random_page_stub import select
ROOT=Path(__file__).resolve().parents[1]
def variant(seed):
    rng=random.Random(seed);controls=[]
    for i in range(4):
        controls.append({'id':f'node-{rng.randrange(100000)}','item':'cup-blue' if i==2 else f'other-{i}',
             'role':'aftersales','label':rng.choice(['申请售后','退款与退货','售后服务']),
             'position':[rng.randrange(1000),rng.randrange(800)],'visible':True})
    truth=controls[2]['id'];rng.shuffle(controls)
    style=rng.randrange(6)
    overlay=None
    if style==1:overlay={'purpose':'notice','data_loss':'none'}
    if style==2:overlay={'purpose':'discard_changes','data_loss':'unsaved_form'}
    if style==3:
        duplicate=dict(next(c for c in controls if c['item']=='cup-blue'));duplicate['id']='duplicate';controls.append(duplicate)
    return {'controls':controls,'overlay':overlay,'loading':style==4}, {'target':'cup-blue','correct_control':truth,'should_locate':style in (0,5)}
def main():
    # Fixed before first run. Held-out results are not used to tune selector.
    splits={'development':list(range(11,31)),'held_out':[1009,1031,1061,1091,1123,1151,1181,1213,1237,1277,1301,1327,1361,1399,1433,1471,1499,1531,1567,1601]}
    rows=[];fixtures=[]
    for split,seeds in splits.items():
        for seed in seeds:
            page,truth=variant(seed);start=time.perf_counter();got=select(page,truth['target']);ms=(time.perf_counter()-start)*1000
            correct=(got['control']==truth['correct_control']) if truth['should_locate'] else got['control'] is None
            # Business target/effect stay fixed across seeds. No downstream effect is executed.
            actual = 'located_not_executed' if got['state']=='located' else 'stopped_or_handoff'
            rows.append({'split':split,'seed':seed,'decision':got,'pass':correct,'elapsed_ms':ms,
                'actual_recovery_success':None,'simulated_outcome':actual,'action_count':0,
                'misoperation':0,'duplicate_external_actions':0,'human_intervention_actual':None,
                'human_handoff_proposed':got['state']=='handoff'})
            fixtures.append({'split':split,'seed':seed,'visible_page':page,'evaluator_only_truth':truth})
    metrics={}
    for split in splits:
        subset=[r for r in rows if r['split']==split];eligible=[r for r in subset if r['decision']['state']=='located']
        metrics[split]={'n':len(subset),'selection_checks_passed':sum(r['pass'] for r in subset),
            'located_not_executed':sum(r['simulated_outcome']=='located_not_executed' for r in subset),
            'stops_or_handoffs':sum(r['simulated_outcome']=='stopped_or_handoff' for r in subset),
            'actual_recovery_success_rate':None,'actual_misoperations':None,'actual_duplicate_external_actions':None,
            'actual_action_count':0,'elapsed_ms':sum(r['elapsed_ms'] for r in subset),
            'proposed_human_handoffs':sum(r['human_handoff_proposed'] for r in subset)}
    result={'type':'synthetic_page_data_and_selector_stub_only','metrics':metrics,'traces':rows,
      'actual_browser_or_model_test':False,'held_out_policy':'Seeds frozen before first run; not used for tuning. Selector receives page+target only.',
      'limitations':'No browser DOM extraction, model invocation, real actions or end-to-end business outcomes. Business target and intended effect fixed across variants; locating is not recovery success.'}
    for name,obj in [('randomized-results.json',result),('evaluator-only-variants.json',fixtures)]:
        (ROOT/'tests'/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(metrics,ensure_ascii=False));return not all(r['pass'] for r in rows)
if __name__=='__main__':raise SystemExit(main())
